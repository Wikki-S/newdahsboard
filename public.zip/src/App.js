import './App.scss';
import { BrowserRouter } from 'react-router-dom'
import { AppRoutes } from './routes'
import Dashboard from './pages/Dashboard/Dashboard';


function App() {
  return (
    <>
      <BrowserRouter>
      {/* <Dashboard /> */}
        <AppRoutes />
      </BrowserRouter>
    </>
  );
}

export default App
