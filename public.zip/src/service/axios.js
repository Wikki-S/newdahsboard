// import axios from 'axios';

// // const BASE_URL = {process.env}

// export const axios.create(
//     // base_url: BASE_URL
//     Headers: Content-Type :'application/json', Accept: 'application/json'
//     )