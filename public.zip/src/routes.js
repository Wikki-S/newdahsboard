import { useRoutes } from "react-router-dom";
import AuthTabs from "./pages/auth-tabs/AuthTabs";
import ForgetPassword from "./pages/auth/forget-password/ForgetPassword";
import Dashboard from "./pages/Dashboard/Dashboard";
import Register from "./pages/register/Register";
import Login from "./pages/login/Login";
import UserManagement from "./pages/innerPage/UserManagement";

export const AppRoutes = () => {
  const elements = useRoutes([
    {
      path: "/nothing",
      element: <AuthTabs />,
    },
    {
      path: "/forget-password",
      element: <ForgetPassword />,
    },
    {
      path: "/dashboard",
      element: <Dashboard />,
    },
    {
      path: "/",
      element: <Register />,
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/user-management",
      element: <UserManagement />,
    },
  ]);

  return elements;
};
