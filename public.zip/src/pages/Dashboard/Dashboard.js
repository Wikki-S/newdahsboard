import React, { useState } from 'react'
import Header from '../DashboardComponent/Header'
import Slider from '../DashboardComponent/Slider'
import Content from '../DashboardComponent/Content';
import './Dashboard.scss'
import { Link } from 'react-router-dom';
import Table from '../table/Table'
import BackDrop from '../../component/backdrop/BackDrop';

function Dashboard(props) {
    const [sideBar, setSideBar] = useState(false);
    const [profile, setProfile] = useState(false);

    const openSidebar = () => {
        setSideBar(!sideBar);
    }
    const closeHanlder = () => {
        setSideBar(false)
    }
    return (
        <>

            <Slider openSidebar={sideBar} onSideBar={setSideBar} />
            <div className={`inner-wrapper ${sideBar == true ? 'close' : 'open'}`}>
                <Header handleSidebar={openSidebar} toggleSidebar={sideBar} />
                <div className='main-container'>
                 { sideBar && <BackDrop onClick={closeHanlder} />} 
                    <Content openSidebar={sideBar} />
    
                
   
                
                
                </div>
            </div>
        </>
    )
}

export default Dashboard