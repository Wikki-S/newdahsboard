import React, { useState } from 'react'
import './Header.scss'
import Button from '../../component/button/Button'
import MenuIcon from '@mui/icons-material/Menu';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import NotificationsIcon from '@mui/icons-material/Notifications';
import CloseIcon from '@mui/icons-material/Close';
import BackDrop from '../../component/backdrop/BackDrop';

function Header(props) {
    const [profile, setProfile] = useState(false);
    const { handleSidebar, toggleSidebar } = props

    const onProfileHandler = () =>{
        setProfile(!profile)
    }
        const closeHanlder = () => {
            setProfile(false);
        }
    return (
        <>
            <nav>
                <div className='nav-toggle'>
                    <div className='toggle' onClick={handleSidebar} >
                        {toggleSidebar == true ? <MenuIcon /> : <CloseIcon />}
                    </div>
                    <ul className='toggle'>
                        <div className='marker'></div>
                        <li className='bell-notification'><NotificationsIcon /></li>

                        <li onClick={onProfileHandler}><AccountCircleIcon /></li>
                    </ul>
                </div>
            </nav>
            {profile && <BackDrop onClick={closeHanlder} />}
            { profile && <div className='profile-menu'>
                <ul>
                    <li>Profile</li>
                    <li>Profile</li>
                    <li>Log out</li>
                </ul>
            </div>
}

        </>
    )
}
export default Header